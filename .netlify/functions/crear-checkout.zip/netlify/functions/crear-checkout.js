const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const PLANES = {
  entrenador: process.env.STRIPE_PRICE_ENTRENADOR,
  analista:   process.env.STRIPE_PRICE_ANALISTA,
  elite:      process.env.STRIPE_PRICE_ELITE,
};

exports.handler = async function(event) {
  if(event.httpMethod !== 'POST'){
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  try {
    const { plan, email, userId } = JSON.parse(event.body);
    const priceId = PLANES[plan];

    if(!priceId){
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Plan no válido' }) };
    }

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      customer_email: email,
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: 'https://tactiqfutbol.es/app.html?pago=ok',
      cancel_url:  'https://tactiqfutbol.es/app.html?pago=cancelado',
      metadata: { userId, plan },
      subscription_data: {
        metadata: { userId, plan }
      }
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ url: session.url })
    };

  } catch(err) {
    console.error('Checkout error:', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: err.message })
    };
  }
};
