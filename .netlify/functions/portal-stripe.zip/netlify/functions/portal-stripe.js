const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { createClient } = require('@supabase/supabase-js');

const sb = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

exports.handler = async function(event) {
  if(event.httpMethod !== 'POST'){
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // Verificar token del usuario
    const authHeader = event.headers.authorization || '';
    const token = authHeader.replace('Bearer ', '');
    if(!token){
      return { statusCode: 401, headers, body: JSON.stringify({ error: 'No autorizado' }) };
    }

    // Obtener usuario desde Supabase
    const { data: { user }, error: authError } = await sb.auth.getUser(token);
    if(authError || !user){
      return { statusCode: 401, headers, body: JSON.stringify({ error: 'Token inválido' }) };
    }

    // Obtener stripe_customer_id del perfil
    const { data: perfil } = await sb.from('perfiles')
      .select('stripe_customer_id, plan')
      .eq('id', user.id)
      .single();

    if(!perfil?.stripe_customer_id){
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'No tienes una suscripción activa. Escríbenos a soporte@tactiqfutbol.es si crees que es un error.' })
      };
    }

    // Crear sesión del portal de Stripe
    const session = await stripe.billingPortal.sessions.create({
      customer: perfil.stripe_customer_id,
      return_url: 'https://tactiqfutbol.es/app.html',
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ url: session.url })
    };

  } catch(err) {
    console.error('Portal error:', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: err.message })
    };
  }
};
