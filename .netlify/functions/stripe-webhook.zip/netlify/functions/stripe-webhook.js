const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

const PRICE_PLANES = {
  [process.env.STRIPE_PRICE_ENTRENADOR]: 'entrenador',
  [process.env.STRIPE_PRICE_ANALISTA]:   'analista',
  [process.env.STRIPE_PRICE_ELITE]:      'elite',
};

exports.handler = async function(event) {
  const sig = event.headers['stripe-signature'];
  let stripeEvent;

  try {
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch(err) {
    console.error('Webhook signature error:', err.message);
    return { statusCode: 400, body: `Webhook Error: ${err.message}` };
  }

  const data = stripeEvent.data.object;

  try {
    switch(stripeEvent.type) {

      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const priceId = data.items?.data?.[0]?.price?.id;
        const plan = PRICE_PLANES[priceId];
        const customerId = data.customer;
        if(!plan) break;

        // Buscar usuario por stripe_customer_id
        const { data: perfil } = await supabase
          .from('perfiles')
          .select('id')
          .eq('stripe_customer_id', customerId)
          .single();

        if(perfil) {
          await supabase.from('perfiles').update({
            plan,
            stripe_subscription_id: data.id,
            stripe_status: data.status,
            plan_renovado_en: new Date().toISOString()
          }).eq('id', perfil.id);
        }
        break;
      }

      case 'customer.subscription.deleted': {
        const customerId = data.customer;
        const { data: perfil } = await supabase
          .from('perfiles')
          .select('id')
          .eq('stripe_customer_id', customerId)
          .single();

        if(perfil) {
          await supabase.from('perfiles').update({
            plan: 'trial',
            stripe_status: 'canceled'
          }).eq('id', perfil.id);
        }
        break;
      }

      case 'invoice.payment_succeeded': {
        const customerId = data.customer;
        const { data: perfil } = await supabase
          .from('perfiles')
          .select('id')
          .eq('stripe_customer_id', customerId)
          .single();

        if(perfil) {
          // Resetear contador de partidos al renovar
          await supabase.from('perfiles').update({
            plan_renovado_en: new Date().toISOString()
          }).eq('id', perfil.id);
        }
        break;
      }
    }

    return { statusCode: 200, body: JSON.stringify({ received: true }) };

  } catch(err) {
    console.error('Webhook handler error:', err);
    return { statusCode: 500, body: 'Internal error' };
  }
};
